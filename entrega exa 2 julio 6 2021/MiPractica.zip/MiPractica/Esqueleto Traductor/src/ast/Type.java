/**
 * @generated VGen (for ANTLR) 1.7.2
 */

package ast;

public interface Type extends AST {
    public int getSize();
	public String getMAPLName();
    public char getSuffix();
}

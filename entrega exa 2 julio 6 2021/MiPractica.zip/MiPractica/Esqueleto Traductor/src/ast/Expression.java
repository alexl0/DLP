/**
 * @generated VGen (for ANTLR) 1.7.2
 */

package ast;

public interface Expression extends AST {

    public boolean isModificable();
    public void setModificable(boolean modificable);
    public Type getType();
    public void setType(Type type);

}

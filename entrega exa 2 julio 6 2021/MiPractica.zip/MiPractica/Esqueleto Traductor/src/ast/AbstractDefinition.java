/**
 * @generated VGen (for ANTLR) 1.7.2
 */

package ast;

public abstract class AbstractDefinition extends AbstractAST implements Definition {

    public void setAddress(int address) {
        this.address = address;
    }

    public int getAddress() {
        return address;
    }

    public int address;
}
